import { createElement } from '../framework/render.js';
import { AbstractComponent } from '../framework/view/abstract-component.js';

export default class FormAddTaskComponent extends AbstractComponent {
    constructor() {
        super(); // обязательно вызываем конструктор родительского класса
    }

    get template() {
        return `
          <form class="new-task_form">
            <h2>Новая задача</h2>
            <div class="input-group">
              <input type="text" name="Название задачи..." placeholder="Название задачи...">
              <input type="button" value="+ Добавить">
            </div>
          </form>
        `;
    }

}
