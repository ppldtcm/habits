import { AbstractComponent } from '../framework/view/abstract-component.js';
import { Status } from '../const.js';

export default class HabitComponent extends AbstractComponent {
  constructor(habit) {
    super();
    this.habit = habit;
  }

  get template() {
    return `
      <div class="habit-item" data-id="${this.habit.id}">
        <h3>${this.habit.name}</h3>
        ${this.habit.description ? `<p>${this.habit.description}</p>` : ''}
        <select class="habit-status" data-testid="status-select">
          <option value="${Status.ACTIVE}" ${this.habit.status === Status.ACTIVE ? 'selected' : ''}>
            Активна
          </option>
          <option value="${Status.COMPLETED}" ${this.habit.status === Status.COMPLETED ? 'selected' : ''}>
            Завершена
          </option>
        </select>
        <button class="delete-button" data-testid="delete-button">Удалить</button>
      </div>
    `;
  }

  setDeleteClickHandler(callback) {
    this._callback.deleteClick = callback;
    this.element.querySelector('.delete-button')
      .addEventListener('click', this.#handleDeleteClick);
  }

  setStatusChangeHandler(callback) {
    this._callback.statusChange = callback;
    this.element.querySelector('.habit-status')
      .addEventListener('change', this.#handleStatusChange);
  }

  #handleDeleteClick = (evt) => {
    evt.preventDefault();
    this._callback.deleteClick(this.habit.id);
  };

  #handleStatusChange = (evt) => {
    evt.preventDefault();
    this._callback.statusChange(this.habit.id, evt.target.value);
  };
}