import { AbstractComponent } from '../framework/view/abstract-component.js';

export default class HabitListComponent extends AbstractComponent {
  constructor(title) {
    super();
    this.title = title;
  }

  get template() {
    return `
      <div class="habit-list">
        <h2>${this.title}</h2>
        <div class="habit-list-container"></div>
      </div>
    `;
  }

  get container() {
    return this.element.querySelector('.habit-list-container');
  }
}