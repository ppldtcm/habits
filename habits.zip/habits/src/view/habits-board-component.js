import { AbstractComponent } from '../framework/view/abstract-component.js';

export default class HabitBoardComponent extends AbstractComponent {
  get template() {
    return `...`; // предыдущий шаблон остается без изменений
  }

  setFormSubmitHandler(callback) {
    this._callback.formSubmit = callback;
    this.element.querySelector('#habit-form').addEventListener('submit', this.#formSubmitHandler);
  }

  #formSubmitHandler = (evt) => {
    evt.preventDefault();
    const form = evt.target;
    const formData = new FormData(form);
    
    const habit = {
      name: formData.get('habit-name'),
      description: formData.get('habit-description'),
      status: formData.get('habit-status')
    };

    this._callback.formSubmit(habit);
    form.reset();
  };
}