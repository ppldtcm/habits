import { AbstractComponent } from '../framework/view/abstract-component.js';

export default class NoHabitsComponent extends AbstractComponent {
  get template() {
    return `
      <div class="no-habits">
        <p>Нет привычек. Добавьте новую привычку.</p>
      </div>
    `;
  }
}