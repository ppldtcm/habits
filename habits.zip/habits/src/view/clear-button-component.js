import { AbstractComponent } from '../framework/view/abstract-component.js';

export default class ClearButtonComponent extends AbstractComponent {
  constructor() {
    super();
  }

  get template() {
    return `
          <button class="button-delete" disabled>Очистить</button>
    `;
  }
}