export const habits = [
    {
      id: "1",
      name: "Утренняя зарядка",
      status: "active",
      description: "15 минут упражнений утром"
    },
    {
      id: "2",
      name: "Чтение книги",
      status: "active",
      description: "30 минут чтения перед сном"
    },
    {
      id: "3",
      name: "Пить воду",
      status: "completed",
      description: "2 литра воды в день"
    }
  ];