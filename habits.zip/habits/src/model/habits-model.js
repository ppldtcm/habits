import { generateId } from '../utils.js';
import { habits } from '../mock/habits.js';

export default class HabitsModel {
  #habits = habits;
  #observers = [];

  get habits() {
    return this.#habits;
  }

  getHabitsByStatus(status) {
    return this.#habits.filter(habit => habit.status === status);
  }

  addHabit({ name, description = '' }) {
    const newHabit = {
      id: generateId(),
      name,
      description,
      status: 'active', // Статус по умолчанию
      createdAt: new Date()
    };

    this.#habits = [newHabit, ...this.#habits];
    this._notifyObservers();
    return newHabit;
  }

  deleteHabit(id) {
    this.#habits = this.#habits.filter(habit => habit.id !== id);
    this._notifyObservers();
  }

  updateHabitStatus(id, newStatus) {
    this.#habits = this.#habits.map(habit => 
      habit.id === id ? { ...habit, status: newStatus } : habit
    );
    this._notifyObservers();
  }

  addObserver(observer) {
    this.#observers.push(observer);
  }

  removeObserver(observer) {
    this.#observers = this.#observers.filter(obs => obs !== observer);
  }

  _notifyObservers() {
    this.#observers.forEach(observer => observer());
  }

  clearCompleted() {
    this.#habits = this.#habits.filter(habit => habit.status !== 'completed');
    this._notifyObservers();
  }
}