import HabitsBoardPresenter from './presenter/habit-board-presenter.js';
import HabitsModel from './model/habits-model.js';

const container = document.getElementById('app');
const habitsModel = new HabitsModel();

const habitsBoardPresenter = new HabitsBoardPresenter({
  container,
  habitsModel
});

habitsBoardPresenter.init();