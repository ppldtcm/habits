import { render } from '../framework/render.js';
import HabitsBoardComponent from '../view/habits-board-component.js';
import HabitListComponent from '../view/habit-list-component.js';
import HabitComponent from '../view/habit-component.js';
import NoHabitsComponent from '../view/no-habits-component.js';
import HeaderComponent from '../view/header-component.js';
import { Status } from '../const.js';

export default class HabitsBoardPresenter {
  #container = null;
  #habitsModel = null;
  #components = {
    header: null,
    board: null,
    list: null,
    habits: new Map()
  };

  constructor({ container, habitsModel }) {
    this.#container = container;
    this.#habitsModel = habitsModel;

    this.#initComponents();
    this.#setupModelObservers();
  }

  init() {
    this.#renderBoard();
    this.#renderHabits();
  }

  #initComponents() {
    this.#components.header = new HeaderComponent();
    this.#components.board = new HabitsBoardComponent();
    this.#components.list = new HabitListComponent();
  }

  #setupModelObservers() {
    this.#habitsModel.addObserver(this.#handleModelChange);
  }

  #renderBoard() {
    render(this.#components.header, this.#container);
    render(this.#components.board, this.#container);
    render(this.#components.list, this.#container);

    this.#components.board.setFormSubmitHandler(this.#handleFormSubmit);
  }

  #renderHabits() {
    this.#clearHabitsList();

    const habits = this.#habitsModel.habits;
    
    if (habits.length === 0) {
      render(new NoHabitsComponent(), this.#components.list.container);
      return;
    }

    habits.forEach(habit => this.#renderHabit(habit));
  }

  #renderHabit(habit) {
    const habitComponent = new HabitComponent(habit);
    habitComponent.setDeleteClickHandler(this.#handleDeleteClick);
    habitComponent.setStatusChangeHandler(this.#handleStatusChange);

    render(habitComponent, this.#components.list.container);
    this.#components.habits.set(habit.id, habitComponent);
  }

  #clearHabitsList() {
    this.#components.list.container.innerHTML = '';
    this.#components.habits.clear();
  }

  #handleModelChange = () => {
    this.#renderHabits();
  };

  #handleFormSubmit = (habitData) => {
    this.#habitsModel.addHabit(habitData);
  };

  #handleDeleteClick = (id) => {
    this.#habitsModel.deleteHabit(id);
  };

  #handleStatusChange = (id, newStatus) => {
    this.#habitsModel.updateHabitStatus(id, newStatus);
  };
}