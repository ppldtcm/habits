export const Status = {
    ACTIVE: 'active',
    COMPLETED: 'completed'
  };
  
  export const StatusLabel = {
    [Status.ACTIVE]: 'Активные',
    [Status.COMPLETED]: 'Завершенные'
  };